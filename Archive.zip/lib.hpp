//
//  lib.hpp
//  new_project
//
//  Created by Yash Khairnar on 16/10/22.
//

#ifndef lib_hpp
#define lib_hpp

#include <stdio.h>
#include <iostream>
using namespace std;

int multiply(int,int);
#endif /* lib_hpp */
