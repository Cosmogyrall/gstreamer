//
//  lib.cpp
//  new_project
//
//  Created by Yash Khairnar on 16/10/22.
//

#include "lib.hpp"

int multiply( int a, int b)
{
    return (a*b);
}
