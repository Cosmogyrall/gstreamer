#!/bin/bash
g++  --verbose -dynamiclib -o mylib.dylib lib.cpp